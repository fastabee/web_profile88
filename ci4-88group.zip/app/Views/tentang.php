<!DOCTYPE html>
<html lang="id">
<head>
  <?= $this->include('templates/head') ?>
  <title>Tentang Kami · 88 Group</title>
  <style><?= $this->include('styles/tentang_style') ?></style>
</head>
<body>
  <div class="container">

    <?= $this->include('templates/navbar') ?>

    <!-- HERO TENTANG -->
    <div class="tentang-hero">
      <div class="tentang-hero-text animate-on-load delay-2">
        <div class="badge"><i class="fas fa-building" style="margin-right:6px;"></i> Tentang Kami</div>
        <h1 style="font-size:3.4rem;font-weight:800;line-height:1.1;margin-bottom:20px;">
          <span style="background:linear-gradient(145deg,#f5e18c,#d4af37);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">88 Group</span><br/>
          <span style="color:#f0ece4;">Warisan</span> <span style="color:#e53935;">Tembakau</span>
        </h1>
        <p style="font-size:1.15rem;color:#c9c1b2;max-width:500px;margin-bottom:32px;line-height:1.8;">
          Perusahaan industri pengolahan hasil tembakau lokal yang telah berdiri sejak <strong style="color:#f5e18c;">1959</strong>, berlokasi di Kabupaten Bondowoso, Jawa Timur. Lebih dari enam dekade menghadirkan cita rasa tembakau pilihan untuk masyarakat Indonesia.
        </p>
        <div class="hero-buttons">
          <a href="<?= base_url('produk') ?>" class="btn-primary"><i class="fas fa-leaf"></i> Lihat Produk</a>
          <a href="#" class="btn-secondary"><i class="fas fa-envelope"></i> Hubungi Kami</a>
        </div>
      </div>
      <div class="tentang-hero-img animate-on-load delay-3">
        <img src="<?= base_url('foto/tentang.jpg') ?>" alt="88 Group - Pabrik Tembakau Bondowoso" />
      </div>
    </div>

    <!-- INFO SINGKAT -->
    <div class="info-grid">
      <div class="info-box">
        <i class="fas fa-calendar-alt"></i>
        <div class="info-label">Berdiri Sejak</div>
        <div class="info-value">1959</div>
      </div>
      <div class="info-box">
        <i class="fas fa-industry"></i>
        <div class="info-label">Jenis Usaha</div>
        <div class="info-value">Industri Pengolahan Hasil Tembakau</div>
      </div>
      <div class="info-box">
        <i class="fas fa-map-marker-alt"></i>
        <div class="info-label">Lokasi</div>
        <div class="info-value">Jl. Husnan Toha, Tamanan, Bondowoso, Jawa Timur</div>
      </div>
      <div class="info-box">
        <i class="fas fa-box-open"></i>
        <div class="info-label">Produk</div>
        <div class="info-value">SKT &amp; SKM (Sigaret Kretek)</div>
      </div>
    </div>

    <!-- SEJARAH & STATISTIK -->
    <section style="padding:0;border-top:none;">
      <div class="sejarah-section">
        <div class="sejarah-text animate-on-load delay-2">
          <div class="badge" style="margin-bottom:20px;"><i class="fas fa-history" style="margin-right:6px;"></i> Sejarah Perusahaan</div>
          <h2 class="section-title" style="text-align:left;margin-bottom:24px;">Enam Dekade <span>Penuh Dedikasi</span></h2>
          <p>88 Group adalah perusahaan industri pengolahan hasil tembakau yang telah berdiri sejak tahun <strong style="color:#f5e18c;">1959</strong>. Berawal dari komitmen sederhana untuk menghadirkan rokok kretek berkualitas, perusahaan ini terus berkembang menjadi salah satu produsen tembakau lokal terpercaya di Kabupaten Bondowoso, Jawa Timur.</p>
          <p>Berlokasi di Jalan Husnan Toha, Sumber Kemuning, Kecamatan Tamanan, 88 Group menjalankan proses produksi dengan standar tinggi — mulai dari pemilihan bahan baku tembakau pilihan hingga proses pengolahan menggunakan peralatan modern maupun metode tradisional yang terjaga kualitasnya.</p>
          <div class="sejarah-highlight">"Dari Bondowoso untuk Indonesia — kami merawat warisan tembakau lokal dengan semangat inovasi dan kepercayaan yang tak pernah pudar."</div>
          <p>Selama lebih dari enam dekade, 88 Group tidak hanya fokus pada produksi, tetapi juga aktif berkontribusi pada pemberdayaan tenaga kerja lokal dan program sosial kemasyarakatan. Perusahaan ini menjalin kerja sama erat dengan pemerintah daerah Kabupaten Bondowoso serta mendapat perhatian nasional dalam pengembangan pemasaran produk tembakau lokal.</p>
        </div>
        <div class="sejarah-stats">
          <div class="stat-card"><div class="stat-num">65+</div><div class="stat-label">Tahun Berpengalaman</div></div>
          <div class="stat-card"><div class="stat-num">6</div><div class="stat-label">Varian Produk Unggulan</div></div>
          <div class="stat-card"><div class="stat-num">1959</div><div class="stat-label">Tahun Berdiri</div></div>
        </div>
      </div>
    </section>

    <!-- JENIS PRODUK -->
    <section>
      <h2 class="section-title animate-on-load delay-1">Jenis <span>Produk</span></h2>
      <p class="section-sub animate-on-load delay-2">88 Group memproduksi dua kategori rokok kretek utama yang telah dikenal luas di pasar lokal maupun nasional.</p>
      <div class="produk-types">
        <div class="produk-type-card">
          <i class="fas fa-hands"></i>
          <div class="tag">SKT</div>
          <h3>Sigaret Kretek Tangan</h3>
          <p>Diproduksi dengan keterampilan tangan para perajin berpengalaman. SKT 88 Group mewarisi tradisi pembuatan rokok kretek yang autentik, menghasilkan cita rasa khas yang tidak tergantikan oleh mesin.</p>
        </div>
        <div class="produk-type-card">
          <i class="fas fa-cogs"></i>
          <div class="tag">SKM</div>
          <h3>Sigaret Kretek Mesin</h3>
          <p>Diproduksi menggunakan teknologi mesin modern dengan presisi tinggi. SKM 88 Group memastikan konsistensi kualitas dan standar produksi yang merata di setiap batang yang dihasilkan.</p>
        </div>
      </div>
    </section>

    <!-- KONTRIBUSI -->
    <section>
      <h2 class="section-title animate-on-load delay-1">Kontribusi <span>Sosial</span></h2>
      <p class="section-sub animate-on-load delay-2">88 Group berkomitmen untuk memberikan dampak positif bagi masyarakat dan daerah sekitar.</p>
      <div class="services-grid">
        <div class="service-card">
          <i class="fas fa-users"></i>
          <h3>Tenaga Kerja <span class="highlight">Lokal</span></h3>
          <p>Menyerap ratusan tenaga kerja dari masyarakat Kabupaten Bondowoso dan sekitarnya, mendukung perekonomian daerah secara nyata.</p>
        </div>
        <div class="service-card">
          <i class="fas fa-handshake"></i>
          <h3>Mitra <span style="color:#d4af37;">Pemerintah</span></h3>
          <p>Menjalin kerja sama aktif dengan pemerintah daerah Kabupaten Bondowoso dalam program sosial kemasyarakatan dan pengembangan industri lokal.</p>
        </div>
        <div class="service-card">
          <i class="fas fa-chart-line"></i>
          <h3>Pemasaran <span style="color:#b71c1c;">Nasional</span></h3>
          <p>Mendapat perhatian di tingkat nasional untuk pengembangan pemasaran produk tembakau lokal, membawa nama Bondowoso ke panggung industri yang lebih luas.</p>
        </div>
      </div>
    </section>

    <!-- LOKASI -->
    <div class="testimoni" style="margin:0 0 10px;">
      <i class="fas fa-map-marker-alt"></i>
      <blockquote style="font-size:1.4rem;"><strong>Jl. Husnan Toha</strong>, Sumber Kemuning, Kec. Tamanan,<br/>Kabupaten Bondowoso, Jawa Timur</blockquote>
      <div class="author">— Kantor &amp; Fasilitas Produksi · <span>88 Group</span></div>
    </div>

    <!-- CTA -->
    <div class="cta-banner">
      <h2><i class="fas fa-leaf"></i> Tertarik bermitra dengan kami?</h2>
      <a href="#" class="btn-primary"><i class="fas fa-arrow-right"></i> Hubungi Sekarang</a>
    </div>

    <?= $this->include('templates/footer') ?>

  </div>
</body>
</html>
