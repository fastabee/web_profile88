<!DOCTYPE html>
<html lang="id">
<head>
  <?= $this->include('templates/head') ?>
  <title>Karir · 88 Group</title>
  <style><?= $this->include('styles/karir_style') ?></style>
</head>
<body>
  <div class="container">

    <?= $this->include('templates/navbar') ?>

    <!-- HERO -->
    <div class="karir-hero animate-on-load delay-2">
      <div class="badge" style="display:inline-block;margin-bottom:20px;">
        <i class="fas fa-briefcase" style="margin-right:6px;"></i> Karir & SDM
      </div>
      <h1>Bergabung Bersama <br/><span style="background:linear-gradient(145deg,#f5e18c,#d4af37);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">88 Group</span></h1>
      <p>Kami percaya bahwa karyawan adalah aset terbesar perusahaan. Bangun karir Anda bersama kami dan tumbuh bersama industri tembakau lokal yang telah berdiri sejak 1959.</p>
      <a href="#lowongan" class="btn-primary"><i class="fas fa-search"></i> Lihat Lowongan</a>
    </div>

    <!-- STATS -->
    <div class="karir-stats">
      <div class="karir-stat"><div class="num">500+</div><div class="lbl">Karyawan Aktif</div></div>
      <div class="karir-stat"><div class="num">65+</div><div class="lbl">Tahun Berdiri</div></div>
      <div class="karir-stat"><div class="num">10+</div><div class="lbl">Program Pelatihan</div></div>
      <div class="karir-stat"><div class="num">95%</div><div class="lbl">Karyawan Lokal</div></div>
    </div>

    <!-- LOWONGAN KERJA -->
    <section id="lowongan">
      <h2 class="section-title animate-on-load delay-1">Lowongan <span>Tersedia</span></h2>
      <p class="section-sub animate-on-load delay-2">Temukan posisi yang sesuai dengan kemampuan dan passion Anda.</p>

      <div class="loker-grid">
        <?php
        $jobs = [
          ['icon' => 'fa-cogs', 'title' => 'Operator Mesin Produksi', 'desc' => 'Mengoperasikan mesin SKM sesuai SOP, memastikan kualitas dan efisiensi produksi harian.', 'dept' => 'Produksi', 'type' => 'Full Time'],
          ['icon' => 'fa-hands', 'title' => 'Perajin Sigaret Kretek Tangan (SKT)', 'desc' => 'Membuat rokok kretek tangan dengan standar kualitas dan target produksi yang ditetapkan perusahaan.', 'dept' => 'Produksi', 'type' => 'Full Time'],
          ['icon' => 'fa-flask', 'title' => 'Quality Control Inspector', 'desc' => 'Melakukan inspeksi dan pengujian kualitas produk di setiap tahap produksi sesuai standar perusahaan.', 'dept' => 'QC / QA', 'type' => 'Full Time'],
          ['icon' => 'fa-truck', 'title' => 'Staff Distribusi & Logistik', 'desc' => 'Mengelola pengiriman produk ke mitra distribusi, koordinasi stok gudang dan jadwal pengiriman.', 'dept' => 'Logistik', 'type' => 'Full Time'],
          ['icon' => 'fa-users-cog', 'title' => 'Staff HRD & Administrasi', 'desc' => 'Mengelola administrasi karyawan, rekrutmen, dan program pelatihan internal perusahaan.', 'dept' => 'HRD', 'type' => 'Full Time'],
        ];
        foreach ($jobs as $j): ?>
        <div class="loker-card">
          <div class="loker-icon"><i class="fas <?= $j['icon'] ?>"></i></div>
          <div class="loker-info">
            <h3><?= $j['title'] ?></h3>
            <p style="font-size:0.88rem;color:#9c927e;margin-top:4px;"><?= $j['desc'] ?></p>
            <div class="loker-meta">
              <span class="loker-tag tag-dept"><?= $j['dept'] ?></span>
              <span class="loker-tag tag-type"><?= $j['type'] ?></span>
              <span class="loker-tag tag-loc"><i class="fas fa-map-marker-alt" style="margin-right:4px;"></i>Bondowoso</span>
            </div>
          </div>
          <a href="#lamar" class="btn-primary"><i class="fas fa-paper-plane"></i> Lamar</a>
        </div>
        <?php endforeach; ?>
      </div>
    </section>

    <!-- BENEFIT -->
    <section>
      <h2 class="section-title animate-on-load delay-1">Benefit <span>Karyawan</span></h2>
      <p class="section-sub animate-on-load delay-2">Kami berkomitmen memberikan kesejahteraan terbaik bagi setiap karyawan.</p>
      <div class="benefit-grid">
        <div class="benefit-card"><i class="fas fa-money-bill-wave"></i><h4>Gaji Kompetitif</h4><p>Remunerasi sesuai standar upah minimum regional dan kompetensi individu.</p></div>
        <div class="benefit-card"><i class="fas fa-heartbeat"></i><h4>BPJS Kesehatan & TK</h4><p>Perlindungan kesehatan dan ketenagakerjaan untuk seluruh karyawan tetap.</p></div>
        <div class="benefit-card"><i class="fas fa-graduation-cap"></i><h4>Pelatihan Berkala</h4><p>Program training rutin untuk meningkatkan skill teknis dan non-teknis.</p></div>
        <div class="benefit-card"><i class="fas fa-chart-line"></i><h4>Jenjang Karir Jelas</h4><p>Sistem promosi transparan berdasarkan kinerja dan pengembangan diri.</p></div>
        <div class="benefit-card"><i class="fas fa-umbrella"></i><h4>THR & Bonus</h4><p>Tunjangan Hari Raya dan bonus kinerja sesuai pencapaian perusahaan.</p></div>
        <div class="benefit-card"><i class="fas fa-users"></i><h4>Lingkungan Kerja Positif</h4><p>Budaya kerja kekeluargaan yang inklusif dan saling mendukung.</p></div>
      </div>
    </section>

    <!-- PROGRAM PENINGKATAN SDM -->
    <section>
      <h2 class="section-title animate-on-load delay-1">Program <span>Peningkatan SDM</span></h2>
      <p class="section-sub animate-on-load delay-2">88 Group berinvestasi pada sumber daya manusia melalui program pengembangan yang terstruktur.</p>
      <div class="sdm-grid">
        <div class="sdm-card">
          <div class="sdm-num">01</div>
          <h3>Pelatihan Teknis Produksi</h3>
          <p>Program orientasi dan pelatihan teknis bagi karyawan baru maupun lama untuk memastikan standar produksi yang konsisten.</p>
          <ul><li>On-the-job training terstruktur</li><li>Sertifikasi keahlian internal</li><li>Evaluasi kinerja berkala</li></ul>
        </div>
        <div class="sdm-card">
          <div class="sdm-num">02</div>
          <h3>Pengembangan Soft Skills</h3>
          <p>Pelatihan kepemimpinan, komunikasi, dan teamwork untuk membentuk karyawan yang profesional dan berdaya saing tinggi.</p>
          <ul><li>Workshop kepemimpinan</li><li>Pelatihan komunikasi efektif</li><li>Team building rutin</li></ul>
        </div>
        <div class="sdm-card">
          <div class="sdm-num">03</div>
          <h3>Program Beasiswa & Studi</h3>
          <p>Dukungan pendidikan bagi karyawan berprestasi yang ingin meningkatkan jenjang pendidikan formal maupun informal.</p>
          <ul><li>Bantuan biaya pendidikan</li><li>Izin belajar bagi karyawan aktif</li><li>Kemitraan dengan lembaga pendidikan</li></ul>
        </div>
      </div>
    </section>

    <!-- FORM LAMAR -->
    <section id="lamar">
      <h2 class="section-title animate-on-load delay-1">Kirim <span>Lamaran</span></h2>
      <p class="section-sub animate-on-load delay-2">Isi formulir di bawah dan kami akan menghubungi Anda segera.</p>

      <div class="form-lamar">
        <h3><i class="fas fa-paper-plane" style="color:var(--gold);margin-right:10px;"></i> Formulir Lamaran Kerja</h3>
        <p>Pastikan data yang Anda isi sudah benar dan lengkap.</p>
        <form action="<?= base_url('karir/submit') ?>" method="post" enctype="multipart/form-data">
          <div class="form-row">
            <div class="form-group"><label>Nama Lengkap *</label><input type="text" name="nama" placeholder="Nama lengkap Anda" required /></div>
            <div class="form-group"><label>Nomor HP / WhatsApp *</label><input type="tel" name="hp" placeholder="08xxxxxxxxxx" required /></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Email</label><input type="email" name="email" placeholder="email@contoh.com" /></div>
            <div class="form-group">
              <label>Posisi yang Dilamar *</label>
              <select name="posisi" required>
                <option value="" disabled selected>— Pilih Posisi —</option>
                <option>Operator Mesin Produksi</option>
                <option>Perajin Sigaret Kretek Tangan (SKT)</option>
                <option>Quality Control Inspector</option>
                <option>Staff Distribusi & Logistik</option>
                <option>Staff HRD & Administrasi</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Pendidikan Terakhir</label>
              <select name="pendidikan">
                <option value="" disabled selected>— Pilih —</option>
                <option>SD</option><option>SMP</option><option>SMA / SMK</option><option>D3</option><option>S1</option><option>S2</option>
              </select>
            </div>
            <div class="form-group">
              <label>Pengalaman Kerja</label>
              <select name="pengalaman">
                <option value="" disabled selected>— Pilih —</option>
                <option>Fresh Graduate / Belum ada pengalaman</option>
                <option>Kurang dari 1 tahun</option>
                <option>1 – 3 tahun</option>
                <option>3 – 5 tahun</option>
                <option>Lebih dari 5 tahun</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group full"><label>Pesan / Motivasi</label><textarea name="pesan" placeholder="Ceritakan motivasi Anda bergabung dengan 88 Group..."></textarea></div>
          </div>
          <div class="form-row">
            <div class="form-group full"><label>Upload CV (PDF / DOC, maks 2MB)</label><input type="file" name="cv" accept=".pdf,.doc,.docx" /></div>
          </div>
          <div style="margin-top:8px;">
            <button type="submit" class="btn-primary" style="width:100%;justify-content:center;font-size:1rem;padding:16px;">
              <i class="fas fa-paper-plane"></i> Kirim Lamaran
            </button>
          </div>
        </form>
      </div>
    </section>

    <!-- QUOTE -->
    <div class="testimoni">
      <i class="fas fa-quote-right"></i>
      <blockquote>"Karyawan kami bukan sekadar tenaga kerja — mereka adalah <strong>keluarga</strong> dan bagian dari <strong>warisan 88 Group</strong> yang terus tumbuh bersama."</blockquote>
      <div class="author">— <span>Manajemen 88 Group</span> · Bondowoso, Jawa Timur</div>
    </div>

    <!-- CTA -->
    <div class="cta-banner">
      <h2><i class="fas fa-briefcase"></i> Ada pertanyaan seputar karir?</h2>
      <a href="#" class="btn-primary"><i class="fas fa-whatsapp"></i> Hubungi HRD</a>
    </div>

    <?= $this->include('templates/footer') ?>

  </div>
</body>
</html>
