<?php

namespace App\Controllers;

class Karir extends BaseController
{
    public function index()
    {
        return view('karir');
    }
}
