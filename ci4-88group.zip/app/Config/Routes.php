<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('produk', 'Produk::index');
$routes->get('tentang', 'Tentang::index');
$routes->get('karir', 'Karir::index');
